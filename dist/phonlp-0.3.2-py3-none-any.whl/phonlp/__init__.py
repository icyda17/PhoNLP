
# -*- coding: utf-8 -*-
from phonlp.run_script import download, load

__version__ = "0.3.2"
__all__ = [
    "download",
    "load",
]
